Build: install JDK 21, then in this folder run:
  gradle wrapper --gradle-version 8.8
  ./gradlew build
Jar appears in build/libs/honeybread-1.0.0.jar
Put it in .minecraft/mods with Fabric Loader 0.16.5+ and Fabric API 0.102.0+1.21.1.
Craft: Bread + Honey Bottle (shapeless).
