package com.example.honeybread;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.component.type.FoodComponent;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class HoneyBreadMod implements ModInitializer {
	public static final String MOD_ID = "honeybread";

	public static final FoodComponent HONEY_BREAD_FOOD = new FoodComponent.Builder()
			.nutrition(8)
			.saturationModifier(0.9f)
			.statusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 100, 0), 1.0f)
			.build();

	public static final Item HONEY_BREAD = Registry.register(
			Registries.ITEM,
			Identifier.of(MOD_ID, "honey_bread"),
			new Item(new Item.Settings().food(HONEY_BREAD_FOOD)));

	@Override
	public void onInitialize() {
		ItemGroupEvents.modifyEntriesEvent(ItemGroups.FOOD_AND_DRINK)
				.register(entries -> entries.add(HONEY_BREAD));
	}
}
